#include <stdio.h>

int main()
{
	printf("FOI!!!!");
	getchar();
	return 0;
}